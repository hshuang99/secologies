---
title: Hong-Sheng Huang
description: This page introduce me.
noIndex: true
hideTOC: false
draft: false
aliases: author
---
> Last update: 2026/September/02

![Hong-Sheng Huang](https://media.secologies.com/author-2.jpg)

Hong-Sheng Huang was born in Taitung, Taiwan. He received his MS degree from the [National Tsing Hua University](https://www.nthu.edu.tw/)'s [Institute of Information Security](https://iis.site.nthu.edu.tw/index.php) at [College of Electrical Engineering and Computer Science](https://eecs.site.nthu.edu.tw/?Lang=zh-tw). And he has joined the [Information Security Laboratory](http://is.cs.nthu.edu.tw/), where Professor [Hung-Min Sun](https://scholars.nthu.edu.tw/esploro/profile/hungmin_sun/overview?institution=886UST_NTHU) is his advisor.

Before that, he received his BS from the [Department of Computer Science and Engineering](https://cse.ntou.edu.tw/?Lang=zh-tw) at [National Taiwan Ocean University](https://www.ntou.edu.tw/). During that time, he joined the Cryptography & Information Security (CIS) Laboratory, where his advisor was Professor [Han-Yu Lin](https://cse.ntou.edu.tw/p/412-1063-7776.php?Lang=zh-tw).

Hong-Sheng's research interests lie in the field of Cryptology and Applied Cryptography.

His personal research focus is centered on Cryptography, whether it involves providing more robust frameworks in various application areas using cryptographic mechanisms or deriving new ideas for cryptographic theory from those application areas that have not yet been considered.

## Info

- Mail: hshuang at secologies dot com
- [Google Scholar Page](https://scholar.google.com/citations?user=nnHNQggAAAAJ&hl=en)

## Publications

### Preprint

\[1\] Hong-Sheng Huang, Yu-Lei Fu, Han-Yu Lin, "The Variant of Designated Verifier Signature Scheme with Message Recovery," 2021, Undergraduate Independent Study. [https://arxiv.org/abs/2403.07820](https://arxiv.org/abs/2403.07820)

### Conference papers

\[5\] Hong-Sheng Huang, Jen-Yi Ho, Hao-Wen Chen and Hung-Min Sun, "EthCluster: An Unsupervised Static Analysis Method for Ethereum Smart Contract," International Conference on Information and Knowledge Management, April, 2025. [https://arxiv.org/abs/2504.09977](https://arxiv.org/abs/2504.09977)

\[4\] Jhih-Zen Shih, Cheng-Che Chuang, Hong-Sheng Huang, Hsuan-Tung Chen and Hung-Min Sun, "An Efficiency Firmware Verification Framework for Public Key Infrastructure with Smart Grid and Energy Storage System," The 9th International Conference on Sustainable Energy Engineering(ICSEE), 2025. [https://arxiv.org/abs/2501.05722](https://arxiv.org/abs/2501.05722)

\[3\] Hong-Sheng Huang, Hung-Min Sun, "Multiplication Strong Logic Locking for NTRU Hardware Scheme," The 34th Cryptology and Information Security Conference(CISC), 2024.

\[2\] Hong-Sheng Huang, Hsuan-Tung Chen, Hung-Min Sun, "An Enhanced Online Certificate Status Protocol for Public Key Infrastructure with Smart Grid and Energy Storage System," The 34th Cryptology and Information Security Conference(CISC), 2024. [https://arxiv.org/abs/2409.10929](https://arxiv.org/abs/2409.10929)

\[1\] Hong-Sheng Huang, Zhe-Yi Jiang, Hsuan-Tung Chen, Hung-Min Sun, "Hybrid Online Certificate Status Protocol with Certificate Revocation List for Smart Grid Public Key Infrastructure," 5th International Congress on Natural Sciences and Engineering(ICNSE), 2024, [https://arxiv.org/abs/2401.10787](https://arxiv.org/abs/2401.10787)


## Employment Experiences

\[3\] Adjunct Research Assistant at [Research Center for Information Technology Innovation (CITI)](https://www.citi.sinica.edu.tw/main) at [Academia Sinica](https://www.sinica.edu.tw/), Taipei, Taiwan (January 2025 - August 2026)

Advisor: [Dr. Tung Chou](https://tungchou.github.io)

\[2\] Research Internship at [National Center for High-performance Computing](https://www.nchc.org.tw/) at [National Applied Research Laboratories](https://www.niar.org.tw/), Hsinchu, Taiwan (July 2023 - August 2023)

Advisor: [Dr. Chun-Yu Lin](https://sites.google.com/site/lincytw/)

\[1\] Information Security Assistant Engineer Internship at [Dynasafe](https://www.dynasafe.com.tw/Default.aspx), Taipei, Taiwan (Mar 2021 - Mar 2022)

## Teaching Experiences

\[6\] Teaching Assistant, [MS in Regulatory Affairs for Drugs & Medical Devices](https://radmd.site.nthu.edu.tw/), [National Tsing Hua University](https://www.nthu.edu.tw/), Hsinchu/[Taipei](https://nbrp.sinica.edu.tw/pages/27), Taiwan (October 2024 ~ June 2026)

\[5\] Teaching Assistant, [Applied Cryptography](https://ocw.nthu.edu.tw/ocw/index.php?page=course&cid=327&), [Institute of Information Security](https://iis.site.nthu.edu.tw/index.php), [National Tsing Hua University](https://www.nthu.edu.tw/), Hsinchu, Taiwan (February 2024 ~ June 2024)

\[4\] Teaching Assistant, Network Security, [Institute of Information Security](https://iis.site.nthu.edu.tw/index.php), [National Tsing Hua University](https://www.nthu.edu.tw/), Hsinchu, Taiwan (September 2023 ~ December 2023)

\[3\] Teaching Assistant, [Cryptography and Network Security](http://is.cs.nthu.edu.tw/course/2022Fall/CS330500/), [Department of Computer Science](https://dcs.site.nthu.edu.tw/index.php), [National Tsing Hua University](https://www.nthu.edu.tw/), Hsinchu, Taiwan (September 2023 ~ December 2023)

\[2\] Teaching Assistant, [Applied Cryptography](https://ocw.nthu.edu.tw/ocw/index.php?page=course&cid=327&), [Institute of Information Security](https://iis.site.nthu.edu.tw/index.php), [National Tsing Hua University](https://www.nthu.edu.tw/), Hsinchu, Taiwan (March 2023 ~ June 2023)

\[1\] Teaching Assistant, [Cryptography and Network Security](http://is.cs.nthu.edu.tw/course/2022Fall/CS330500/), [Department of Computer Science](https://dcs.site.nthu.edu.tw/index.php), [National Tsing Hua University](https://www.nthu.edu.tw/), Hsinchu, Taiwan (September 2022 ~ December 2022)

## Service

- PeerJ Computer Science Journal Reviewer

## Talks

\[1\] "你生活中那些苗頭不對的資訊科技," 生活資安主題課程 資訊科技領域, 國立清華大學苗栗縣 STEAM 教育中心, 台達館102教室, 國立清華大學校本部, 新竹市光復路二段101號, 臺灣, 114 年 1 月 23 日.

## Honors and Awards

\[1\] [Employee of Year Top Award](https://media.secologies.com/Dynasafe-Top-Award.webp), Dynasafe Technologies, Inc, 2022.

## Licenses & Certifications

\[5\] [EC-Council Certificated Ethical Hacker](https://media.secologies.com/ECC-CEH-Certificate.webp)
\[4\] [CompTIA Security+ Certification](https://media.secologies.com/CompTIA-Security-ce-certificate.webp) 
\[3\] [Ministry of Economic Affairs (Taiwan) MOEA Certified Information Security Engineer Associate Level](https://media.secologies.com/MOEA-InformationSecurity-Certificate.webp)
\[2\] [Microsoft Technology Associate: Networking Fundamentals (MTA)](https://media.secologies.com/MTA-Networking.webp) 
\[1\] [Microsoft Technology Associate: Security Fundamentals (MTA)](https://media.secologies.com/MTA-Security.webp)
