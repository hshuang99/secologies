---
title: "2026 Real World Crypto 研討會 於 臺北舉辦 活動日期：2026年3月9號至11號"
date: 2026-01-21
description: Real World Crypto 研討會是由國際密碼研究學會 (The International Association for Cryptologic Research, IACR) 所組織的其中一場活動，該研討會宗旨是將學界與工程界之間建立橋樑，共同探討在現實世界實作密碼系統上會遇到哪些問題
tags: 
  - "iacr"
  - "real-world-cryptography-symposium"
  - "the-international-association-for-cryptologic-research"
  - "workshop"
  - "國際密碼研究學會"
targetKeyword: Real World Crypto 研討會
draft: false
lang: zh
---
Real World Crypto 研討會是由國際密碼研究學會 (The International Association for Cryptologic Research, IACR) 所組織的其中一場活動，該研討會宗旨是將學界與工程界之間建立橋樑，共同探討在現實世界實作密碼系統上會遇到哪些問題

例如在網際網路、雲端以及嵌入式裝置等環境中實作密碼系統時，有哪些方法可以加速執行效率、減少所需記憶體空間，更甚者提出理論上可以攻擊的假說，並且由開發人員來證明該假說，以此點出雙方都需要理解的盲區

今年很幸運由中研院資科所的兩位頂尖密碼研究員[楊柏因老師](https://homepage.iis.sinica.edu.tw/pages/byyang/contact_zh.html)跟[鐘楷閔老師](https://homepage.iis.sinica.edu.tw/pages/kmchung/contact_zh.html)主持，目前已開放訂票，早鳥票價到2月6號之前，超過這日期後，票價至少會漲100鎂，所以還是推薦各位早點買，可以參考官網：[https://rwc.iacr.org/2026/registration.php](https://rwc.iacr.org/2026/registration.php)

並且該研討會跟 IACR 其他純理論的活動不太一樣，由於是工程性質的討論，自然也會一同舉辦其他 Workshop 活動，一樣可以在官方看到 [https://rwc.iacr.org/2026/affiliated.php](https://rwc.iacr.org/2026/affiliated.php)

同場加映的是第四屆 Real World 後量子密碼 Workshop、2026 Real World MPC (Multi-Party Computation)、第四屆開源密碼 Workshop 以及第五屆由 FHE 組織舉辦的同態加密 Workshop

但 Workshop 的票還得額外購買，所以各位自行斟酌

