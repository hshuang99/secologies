---
title: "量子錯誤更正發展工作坊 參與心得"
date: 2025-12-29
description: "於2025年底由賴青沂教授 hosting 的這場量子錯誤更正碼 (Quantum Error-Correction Codes, QEC) 工作坊，原本預期以 Advances 為核心，展示最新前沿研究內容"
hideTOC: false
targetKeyword: 量子錯誤更正碼
draft: false
tags: 
  - "qldpc"
  - "qubit"
  - "workshop"
  - "量子容錯計算"
  - "量子輔助位元"
  - "量子錯誤更正碼"
lang: zh
---
於2025年底由[賴青沂教授](https://sites.google.com/view/ching-yi-lai) hosting 的這場量子錯誤更正碼 (Quantum Error-Correction Codes, QEC) 工作坊，原本預期以 Advances 為核心，展示最新前沿研究內容，由於需要滿足教育部的規劃，所以一部分授課得從初階的notations先介紹，但也因為如此，參與的人除了一半來自電機、資訊領域，剩下還有物理跟數學背景的學術人參與。

令人意外的是還有一些業界的先進來聽，問的問題都比較偏向工程上可以實現的 Surface code 或是 QLDPC code 效率、實作可行性等，國內其實已經蠻多家廠商在關注小型量子電腦，或 FPGA 上的實驗性實作處理少量 qubit 的演算法。

但，老話一句，不管是在 Superconducting、ION Trap、Photonic 或是 Spin 等架構或是模擬器上，錯誤率還是太高了，2024 年 105-qubit 的 Google Willow 量子晶片中[^1]，single-qubit gate error 還有 0.035%$\pm$0.029%，而 Two-qubit gate error 則有 0.33%$\pm$0.18%。

我們傳統上許多的 codeword 要轉換進量子世界傳輸，都至少需要倚賴 Two-qubit 的 gates，因為要在量子電路上實作有效率的解碼器，勢必需要額外的輔助量子位元來保護原本的資訊。

而傳統上的 Belief Propagation algorithm 放在量子電路中還是非常有用的，甚至表現超乎我們的預期，所以 Quantum Low-Density Parity-Check (QLDPC) Codes 配上其他種的 redundancy 等研究還是很火熱。

不過想要造出好的 Fault-Tolerant 錯誤更正碼，原本 Calderbank-Shor-Steane code 也不容錯過，尤其要面對 Surface code 或 Toric Code，甚至面對 Hypergraph product (HGP) codes 這類較為特殊的結構，我們要弄成 Stabilizer codes 放進量子電路裡的話，還有很多工作要做。

因此在本次活動中，除了介紹造 code、編碼、解碼等過程，也邀請[陳郁方研究員](https://guluchen.github.io/)探討我們在建立這些 code 時，用一些 symbolic execution 來探索每一個 parity-check matrix 的組成是否合理，是否有相同的 symdrome 卻需要不同的解碼器來運作呢？

劉博士探討小型量子電腦的電路干擾也讓人很驚艷，原來連空的 Idle wire 都有可能被錯誤干擾，導致要傳輸給 gate 的資訊錯誤，這使得我們需要更多的 ancillia qubit 模擬 memory 來儲存當下的資訊。

誠如賴老師所言，在量子錯誤更正碼領域中，即使已經過了十幾、二十年的發展，還是有許多事情要弄，而這些尚未探索的世界等著我們去挖掘，讀者可以想像通訊領域是一個在研究跟工程上關係都非常緊密的一條路，意思是你修課時學到的理論，以及做的那些 Project 基本上業界都還有在持續發展

所以不管你的背景是電機、資訊、物理抑或是數學，你都可以在 QEC 中找到你能貢獻的一片天地，總歸來說，如果有興趣的讀者都可以從自身的背景來延伸，便會發現這個領域是如此之廣泛。

[^1]: Hartmut Neven, "Meet Willow, our state-of-the-art quantum chip," Google Quantum AI, Dec 09, 2024, [https://blog.google/technology/research/google-willow-quantum-chip/](https://blog.google/technology/research/google-willow-quantum-chip/)

